@echo off
mvn -q package
java -cp "target/classes;lib/*" com.example.migrator.MigrationApplication MIGRATE
pause
